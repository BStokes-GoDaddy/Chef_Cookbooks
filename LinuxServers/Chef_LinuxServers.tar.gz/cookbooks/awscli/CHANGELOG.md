## 1.1.2 2015-09-18

BUG FIXES:

  * Added checks to metadata source_url and issues_url for Chef 11 compatibility ([@nickryand][])

## 1.1.1 2015-05-26

* Updated metadata.rb to show proper source and issues link on supermarket ([@nickryand][])

## 1.1.0 2015-05-26

* Added owner, group, and mode parameters to the s3_file resource ([@nickryand][])

## 1.0.1 2015-01-10

* Updated Berksfile to point to https://supermarket.chef.io ([@nickryand][])

## 1.0.0 2015-01-06

Initial Release ([@nickryand][])

[@nickryand]: https://github.com/nickryand
