#
# Cookbook Name:: LinuxServers
# Recipe:: pkgPython2
#
# Copyright (c) 2016 Bill Stokes, All Rights Reserved.
include_recipe 'python::default'
