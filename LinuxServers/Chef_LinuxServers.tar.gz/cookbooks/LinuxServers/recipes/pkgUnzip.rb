#
# Cookbook Name:: LinuxServers
# Recipe:: unzip
#
# Copyright (c) 2016 Bill Stokes, All Rights Reserved.
package "unzip" do
  action :install
end
