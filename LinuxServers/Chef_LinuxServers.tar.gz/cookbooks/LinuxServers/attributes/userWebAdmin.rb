
# Web User
default['LinuxServers']['userWebAdmin']['user'] = 'web_admin'
default['LinuxServers']['userWebAdmin']['group'] = 'web_admin'
