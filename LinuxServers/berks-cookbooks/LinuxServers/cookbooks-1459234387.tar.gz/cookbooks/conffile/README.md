[![Build Status](https://travis-ci.org/optiflows-cookbooks/conffile.png)](https://travis-ci.org/optiflows-cookbooks/conffile)
# conffile cookbook

# Requirements

# Usage

# Attributes

# Recipes

# Author

Author:: Guilhem Lettron (<guilhem.lettron@optiflows.com>)
